<div id="execRight">
<h3>
LDS Executive Coaching offers four options of personal and team development:
</h3>
<ol>
	<li><a href="leadershipjourney.php">The Leadership Journey</a></li>
	<li><a href="emotionalintel.php">Emotional Intelligence Assessment</a></li>
	<li><a href="bestyearyet.php">Your Best Year Yet</a></li>
	<li><a href="focusvision.php">Focus Your Vision</a></li>
</ol>
</p>
</div>
<br style="clear:both;">