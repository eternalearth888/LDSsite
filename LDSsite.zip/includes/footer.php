<footer>
	<div class="contact">
		<table id="contactFooter">
			<thead id="contactFooterHead">
				<tr>
					<td colspan="3">
						Contact Dr. Elia Gourgouris
					</td>
				</tr>
			</thead>
			<tbody>
				<tr id="title">
					<td>Phone</td>
					<td>Email</td>
					<td>Address</td>
				</tr>
				<tr>
					<td id="phone">
						(303) 523-6396
					</td>
					<td id="email">
						<a href="mailto:DrEliaGourgouris@msn.com">DrEliaGourgouris@msn.com</a>
					</td>
					<td id="address">
						<address>
							1106 E. Roggen Way
							<br />
							Superior, CO 80027
						</address>
					</td>
				</tr>
				<tr>
					<td colspan="3">
						Executive Coach ● Leadership Development ● Relationship Expert
					</td>
			</tbody>
		</table>
	</div>
	<div class="copyrightFooter">
		&copy; <?php echo date("Y") ?> LDS Executive Coaching
	</div>
</footer>