<div class="testTop">
	<div id="LDS">
		Transforming businesses through
		<br />
		<div id="highlight1">L</div>eadership 
		<br />
 		<div id="highlight2">D</div>evelopment
 		<br />
          	<div id="highlight3">S</div>olutions
	</div>
</div>