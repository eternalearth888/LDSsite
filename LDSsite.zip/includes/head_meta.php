<meta name="viewport" content="user-scalable=0;"/>
<meta name="description" content="LDS Executive Coaching: Transforming business through Leadership, Development, Solutions ">
<meta name="keywords" content="Dr. Elia Gourgouris, Executive, Coaching, LDS, Leadership, Development, Solutions, executive coaching">
<meta charset="UTF-8">
<head>
	<title> LDS Executive Coaching</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<!--[if lt IE 9]> <script src="html5shiv.js"></script> <![endif]-->
</head>