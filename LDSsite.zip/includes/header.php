<header>
	<div class="parentHeader">
		<div class="leftHeader">
			<div id="eliaImage">
				<img src="images/elias.jpg" alt="Dr. Elia Gourgouris" />
			</div>
			<div id="eliaName">
				Dr. Elia Gourgouris
			</div>
		</div>
		<div class="mainHeader">
			<div id="topLogo">
				LDS Executive Coaching
			</div>
			<div id="bottomLogo">
				Executive Coach ● Leadership Development ● Relationship Expert
			</div>
		</div>
	</div>
	<?php require('navigation.php'); ?>
</header>
<div class="block">
</div>