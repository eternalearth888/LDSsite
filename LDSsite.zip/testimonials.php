<!DOCTYPE html>
<html>
<?php require('includes/head_meta.php'); ?>

	<body>
		<?php require('includes/header.php'); ?>
		<div class="wrapper">
			<?php require('includes/LDSBlock.php'); ?>
			<div id="change">
				<?php include('content/testimonials.php'); ?>
			</div>
		</div>
		<?php require('includes/footer.php'); ?>
	</body>
</html>