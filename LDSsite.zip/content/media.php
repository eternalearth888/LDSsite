<div id="quoteTop">
	<h6>"After all, happiness is the ultimate success in life!!!”</h6>
	<h1>-Dr. Elia Gourgouris</h1>
</div>
<h2>Media</h2>
<h3>Dr. Gourgouris on "The Home Team"</h3>
<center><iframe width="560" height="315" src="//www.youtube.com/embed/7_9mn0vCLXc" frameborder="0" allowfullscreen></iframe></center>
<h3>Dr. Gourgouris on Studio5</h3>
<center><iframe width="560" height="315" src="//www.youtube.com/embed/EfIEgyAOk8g" frameborder="0" allowfullscreen></iframe></center>
<h3>Dr. Gourgours on "The Home Team"</h3>
<center><iframe width="560" height="315" src="//www.youtube.com/embed/5bUgQLU_3sE" frameborder="0" allowfullscreen></iframe></center>
<div id="quoteBottom">
</div>